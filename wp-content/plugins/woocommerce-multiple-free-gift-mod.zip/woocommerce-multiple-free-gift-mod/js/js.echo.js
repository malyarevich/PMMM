jQuery(document).ready(function() {
    jQuery("#wfgm-btn-ok").click(function () {
        jQuery('.wfgm-so-popup').hide(900);
        jQuery('.wfgm-overlay').hide(600);
    });

    jQuery("#wfgm-btn-add-gift").click(function () {
        jQuery('.wfgm-so-popup').hide(900);
        jQuery('.wfgm-overlay').hide(600);
    });
});