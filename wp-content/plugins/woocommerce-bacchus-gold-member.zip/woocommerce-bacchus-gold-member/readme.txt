=== Woocommerce Bacchus Gold Loyalty Program Plugin ===
Contributors: Yevgen
Tags: woocommerce, Woocommerce Bacchus Gold Member, woocommerce gift management, woocommerce multiple gifts, woocommerce multiple free gifts, woocommerce gift manager, woocommerce plugin, woocommerce freebies, woocommerce prizes
Requires at least: 3.8
Tested up to: 4.5.3
WC requires at least: 2.3
WC tested up to: 2.4.6
Stable tag: 1.1.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WooCommerce giveaway made easy. Best way to offer freebies, gifts or prizes.

== Description ==
Gift giving is one of the best ways for marketing. This way creates good vibes and your customers will come back more often.

Bacchus Gold Loyalty Program Plugin is a WordPress WooCommerce plugin that makes gift management easy for your woocommerce site. The plugin helps you offer free products or gifts to your customer when they purchase products at your store. Woocommerce Bacchus Gold Member plugin - gives you an edge by allowing you to write your own gift conditions which gives you great control on how you want to provide gifts to your customer.

> **A NOTE ABOUT SUPPORT:** We’re here to help troubleshoot bugs, but please don't set expectations early as the support forums at WordPress.org are only checked every two days.

**Overview**
Woocommerce Bacchus Gold Member Plugin enables the option to provide gifts to your customer. Gift Giving is one of the best ways for marketing. This way creates good vibes and your Customers will come back more often. With Woocommerce Bacchus Gold Member Plugin you can provide gifts to your customer based on single or multiple products.

**Features**

== Installation ==

1. Unzip and upload the `woocommerce-bacchus-gold-member` directory to the plugin directory (`/wp-content/plugins/`) or install it from `Plugins->Add New->Upload`.
2. Activate the plugin through the `Plugins` menu in WordPress.
3. That's all you need to do. You will notice Woo Free Gift settings page in the admin.

== Screenshots ==

== Changelog ==
= 0.0.0 =
* First release.
